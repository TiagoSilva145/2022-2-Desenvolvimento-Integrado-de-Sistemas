/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.guititi.testeblasmaven;

/**
 *
 * @author tiago145
 */
public class ImageRequest {
    public String userId;
    public int model;
    public int alg;
    public AlgorithmEnum algorithm;
    public int imageSize;
    public int sampleLenght;
    public int sensorNum;
    public int g;
}

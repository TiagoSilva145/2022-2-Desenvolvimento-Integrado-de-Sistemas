/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.guititi.testeblasmaven;

/**
 *
 * @author tiago145
 */
public enum AlgorithmEnum {
    CGNE(0), CGNR(1);
    public int valor;
    
    AlgorithmEnum(int v) {
        valor = v;
    }
}
